import java.lang.AssertionError;
import java.lang.FunctionalInterface;
import java.lang.Long;
import java.lang.Object;
import java.lang.String;
import java.lang.Throwable;
import java.util.List;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
/** Проверяющий клиент: передаёт те же объекты и массивы входам Study. */
class TaskBinding {
    @FunctionalInterface
    private interface Invocation<T> {
        T run() throws Throwable;
    }
    private static <T> T invoke(Invocation<T> call) throws Throwable {
        return call.run();
    }
    static Object customer(long id, String l, String f, String m, String c) throws Throwable {
        return invoke(()->Study.customer(id, l, f, m, "Учебный адрес", c, "Счёт" + id));
    }
    static Object shortValue(long id, String s) throws Throwable {
        Object c = invoke(()->Study.secondConstructor());
        validRecord(c);
        return c;
    }
    static Object[] array(Object... v) throws Throwable {
        Object[] a = invoke(()->Study.array(v));
        typed(a, v);
        return a;
    }
    static Object[] sorted(Object[] a) throws Throwable {
        return invoke(()->Study.sorted(a));
    }
    static Object[] range(Object[] a, String l, String h) throws Throwable {
        return invoke(()->Study.inCardRange(a, l, h));
    }
    static List < ? > value(Object x) throws Throwable {
        return invoke(()->Study.values(x));
    }
    static void edit(Object c, long id, String l, String f, String m, String a, String card, String account) throws Throwable {
        invoke(()->{
            Study.edit(c, id, l, f, m, a, card, account);
            return null;
        });
    }
    static String text(Object c) throws Throwable {
        return invoke(()->Study.text(c));
    }
    static void validRecord(Object c) throws Throwable {
        List < ? > v = invoke(()->Study.values(c));
        if (v.size() != 7 || !(v.get(0) instanceof Long id) || id <= 0)
            throw new AssertionError("Недопустимая запись второго конструктора");
        for (int i = 1; i < 7; i++)
            if (!(v.get(i) instanceof String s) || s.isEmpty()) throw new AssertionError("Пустое свойство");
        if (!((String)v.get(5)).matches("[0-9]{16}")) throw new AssertionError("Номер карточки");
    }
    static void typed(Object[] a, Object[] values) throws Throwable {
        if (a == null || a.getClass().getComponentType() == Object.class || a.length != values.length)
            throw new AssertionError("Требуется массив класса модели");
        if (a.length == 0 && !a.getClass().getComponentType().isInstance(invoke(()->Study.customer(
                                 11, "Иванов", "Антон", "Ильич", "Учебный адрес", "0000000000000010", "Счёт11"))))
            throw new AssertionError("Компонент пустого массива не относится к модели");
        for (int i = 0; i < a.length; i++)
            if (a[i] != values[i]) throw new AssertionError("Ссылки и порядок массива");
    }
}
