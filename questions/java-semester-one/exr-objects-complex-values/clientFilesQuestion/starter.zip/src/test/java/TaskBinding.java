import java.util.Arrays;
import java.lang.AssertionError;
import java.lang.FunctionalInterface;
import java.lang.Object;
import java.lang.Throwable;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
/** Проверяющий клиент: передаёт те же объекты и массивы входам Study. */
class TaskBinding {
    @FunctionalInterface
    private interface Invocation<T> {
        T run() throws Throwable;
    }
    private static <T> T invoke(Invocation<T> call) throws Throwable {
        return call.run();
    }
    static Object value(double r, double i) throws Throwable {
        return invoke(()->Study.complex(r, i));
    }
    static double[] parts(Object x) throws Throwable {
        return invoke(()->Study.parts(x));
    }
    static Object operation(Object a, Object b, int op) throws Throwable {
        return switch (op) {case 0->invoke(()->Study.add(a,b));case 1->invoke(()->Study.subtract(a,b));case 2->invoke(()->Study.multiply(a,b));default->invoke(()->Study.divide(a,b));};}static Object[] array(Object...v) throws Throwable{Object[] a=invoke(()->Study.array(v));typed(a,v);return a;}static Object sum(Object[] a) throws Throwable{return aggregate(a,false);}static Object product(Object[] a) throws Throwable{return aggregate(a,true);}static Object aggregate(Object[] a,boolean product) throws Throwable{Object[] before=a.clone();double[][] state=new double[a.length][];for(int i=0;i<a.length;i++)state[i]=parts(a[i]).clone();Object result=invoke(()->product?Study.product(a):Study.sum(a));
                for (int i = 0; i < a.length; i++)
                    if (before[i] != a[i] || !Arrays.equals(state[i], parts(a[i])))
                        throw new AssertionError("Операция изменила исходный массив или его элементы");
                return result;
        }
        static void typed(Object[] a, Object[] values) throws Throwable {
            if (a == null || a.getClass().getComponentType() == Object.class || a.length != values.length)
                throw new AssertionError("Требуется массив класса модели");
            if (a.length == 0 && !a.getClass().getComponentType().isInstance(invoke(()->Study.complex(1, 1))))
                throw new AssertionError("Компонент пустого массива не относится к модели");
            for (int i = 0; i < a.length; i++)
                if (a[i] != values[i]) throw new AssertionError("Ссылки и порядок массива");
        }
    }
