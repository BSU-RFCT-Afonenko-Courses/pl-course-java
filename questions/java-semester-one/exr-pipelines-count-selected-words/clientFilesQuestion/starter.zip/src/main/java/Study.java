import java.util.*;import java.util.function.*;import java.nio.file.Path;
/** Связь с собственным решением; модель и алгоритм создайте самостоятельно. */
public class Study {
    public static void printCounts(String text,List<String> queries) { throw new UnsupportedOperationException("TODO: реализуйте по условию"); }
}
